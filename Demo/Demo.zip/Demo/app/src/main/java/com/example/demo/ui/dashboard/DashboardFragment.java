package com.example.demo.ui.dashboard;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.content.Intent;
import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import android.widget.Button;
import com.example.demo.R;

public class DashboardFragment extends Fragment {

    private DashboardViewModel dashboardViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        dashboardViewModel =
                ViewModelProviders.of(this).get(DashboardViewModel.class);
        View root = inflater.inflate(R.layout.fragment_dashboard, container, false);
        return root;
    }
    @Override
    public void onActivityCreated(Bundle savedInstanceState){
        super.onActivityCreated(savedInstanceState);
        Button timeButton=(Button)getActivity().findViewById(R.id.button_time);
        timeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //从fragment跳转到activity中
                startActivity(new Intent(getActivity(), ChartByTime.class));
            }
        });
        Button classButton=(Button)getActivity().findViewById(R.id.button_class);
        classButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public  void onClick(View v){
                //从fragment跳转到activity中
                startActivity(new Intent(getActivity(),ChartByClass.class));
            }
        });
        Button countryButton = (Button)getActivity().findViewById(R.id.button_country);
        countryButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                startActivity(new Intent(getActivity(),ChartByCountry.class));
            }
        });
        Button mailButton=(Button)getActivity().findViewById(R.id.button_searchMail);
        mailButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent=new Intent(getActivity(),SearchActivity.class);
                intent.putExtra("class","mail");
                startActivity(intent);
            }
        });
        Button idCardButton=(Button)getActivity().findViewById(R.id.button_searchIdCard);
        idCardButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent=new Intent(getActivity(),SearchActivity.class);
                intent.putExtra("class","idcard");
                startActivity(intent);
            }
        });
        Button passportButton=(Button)getActivity().findViewById(R.id.button_searchPassport);
        passportButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent=new Intent(getActivity(),SearchActivity.class);
                intent.putExtra("class","passport");
                startActivity(intent);
            }
        });
    }

}