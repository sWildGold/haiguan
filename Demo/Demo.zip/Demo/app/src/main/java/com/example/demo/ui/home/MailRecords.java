package com.example.demo.ui.home;

import android.Manifest;
import android.annotation.TargetApi;
import android.content.ContentUris;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.net.sip.SipSession;
import android.os.Build;
import android.os.Bundle;

import com.example.demo.database.DatabaseService;
import com.example.demo.database.Mail;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import android.os.Environment;
import android.os.StrictMode;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintJob;
import android.print.PrintManager;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.text.Layout;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.demo.R;
import com.rengwuxian.materialedittext.MaterialEditText;
import com.weiwangcn.betterspinner.library.material.MaterialBetterSpinner;
import com.wildma.pictureselector.PictureSelector;
import com.yanzhenjie.permission.Action;
import com.yanzhenjie.permission.AndPermission;
import com.yanzhenjie.permission.runtime.Permission;

import org.w3c.dom.Text;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class MailRecords extends AppCompatActivity {
    private PrintManager mgr=null;
    private ImageView imageView;
    private Button btnCamera;
    private Button btnSave;
    private static final String[] COUNTRIES = new String[] {
            "日用品","食品","文件","数码产品","衣物","其他"
    };
    private String picturePath;
    private Button btnPrint;
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        mgr=(PrintManager)getSystemService(PRINT_SERVICE);
        if (android.os.Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mail_records);
        Toolbar toolbar = findViewById(R.id.toolbar_mail_records);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        btnCamera=(Button)findViewById(R.id.button_camera);
        imageView=(ImageView)findViewById(R.id.image_show);
        btnPrint=(Button)findViewById(R.id.button_mail_records_print);
        btnSave=(Button)findViewById(R.id.button_mail_records_save);
        btnCamera.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                PictureSelector
                        .create(MailRecords.this, PictureSelector.SELECT_REQUEST_CODE)
                        .selectPicture(false, 200, 200, 1, 1);

            }
        });
        btnPrint.setOnClickListener(new View.OnClickListener(){
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onClick(View v){

                AndPermission.with(MailRecords.this)
                        .runtime()
                        .permission(
                                Permission.WRITE_EXTERNAL_STORAGE,
                                Permission.READ_EXTERNAL_STORAGE

                        )
                        .onGranted(new Action<List<String>>() {
                            @Override
                            public void onAction(List<String> permissions) {
                                Toast toast=Toast.makeText(MailRecords.this,"授权成功",Toast.LENGTH_SHORT    );
                                toast.setGravity(Gravity.CENTER, 0, 0);
                                toast.show();
                                MaterialEditText editText=findViewById(R.id.mail_records_edittext1);
                                //String path = Environment.getExternalStorageDirectory() + File.separator + editText.getText().toString() +".pdf";
                                String path = Environment.getExternalStorageDirectory() + File.separator  +"Record.pdf";
                                Toast toast11=Toast.makeText(MailRecords.this,path,Toast.LENGTH_SHORT    );
                                toast11.setGravity(Gravity.CENTER, 0, 0);
                                toast11.show();
                                PdfDocument document = new PdfDocument();
                                // ll_model是一个LinearLayout
                                LinearLayout ll_model=(LinearLayout) findViewById(R.id.mail_layout);
                                PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(ll_model.getWidth(),ll_model.getHeight(),1).create();
                                PdfDocument.Page page = document.startPage(pageInfo);
                                ll_model.draw(page.getCanvas());
                                document.finishPage(page);

                                try {
                                    File e = new File(path);
                                    if (e.exists()) {e.delete();}
                                    document.writeTo(new FileOutputStream(e));
                                    Toast toast1=Toast.makeText(MailRecords.this,"已保存",Toast.LENGTH_SHORT);
                                    toast1.setGravity(Gravity.CENTER, 0, 0);
                                    toast1.show();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                    Toast toast1=Toast.makeText(MailRecords.this,"请重试",Toast.LENGTH_SHORT);
                                    toast1.setGravity(Gravity.CENTER, 0, 0);
                                    toast1.show();
                                }
                                document.close();
                                String authority = "com.example.demo.provider";
                                File outputFile = new File(path);
                                //Uri uri = FileProvider7.getUriForFile(this, outputFile);
                                //Uri uri = FileProvider.getUriForFile(MailRecords.this, authority, outputFile);

                                Intent share = new Intent();
                                share.setAction(Intent.ACTION_VIEW);
                                share.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                Uri uri = FileProvider.getUriForFile(MailRecords.this, authority, outputFile);
                                //Uri uri = Uri.fromFile(outputFile);
                                share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                share.setDataAndType(uri, "application/pdf");
                                //share.putExtra(Intent.EXTRA_STREAM, uri);
                                //share.setDataAndType(uri, "application/pdf");
                                startActivity(share);
                            }
                        })
                        .onDenied(new Action<List<String>>() {
                            @Override
                            public void onAction(List<String> permissions){
                                Toast toast=Toast.makeText(MailRecords.this,"授权失败",Toast.LENGTH_SHORT    );
                                toast.setGravity(Gravity.CENTER, 0, 0);
                                toast.show();
                            }
                        })
                        .start();


            }
        });
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_dropdown_item_1line, COUNTRIES);
        MaterialBetterSpinner textView = (MaterialBetterSpinner)
                findViewById(R.id.mail_records_spinner);
        textView.setAdapter(adapter);
        btnSave.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Mail m=new Mail();
                DatabaseService dbserver=DatabaseService.getDbService();
                MaterialEditText editText;
                editText=findViewById(R.id.mail_records_edittext1);
                m.setMail_id(editText.getText().toString());
                editText=findViewById(R.id.mail_records_sender_info_edittext1);
                m.setSender_name(editText.getText().toString());
                editText=findViewById(R.id.mail_records_sender_info_edittext2);
                m.setSender_tel(editText.getText().toString());
                editText=findViewById(R.id.mail_records_sender_address_edittext1);
                m.setSending_country(editText.getText().toString());
                editText=findViewById(R.id.mail_records_sender_address_edittext2);
                m.setSending_district(editText.getText().toString());
                editText=findViewById(R.id.mail_records_sender_address_edittext4);
                m.setSending_district_in_detail(editText.getText().toString());
                editText=findViewById(R.id.mail_records_receiver_info_edittext1);
                m.setReceiver_name(editText.getText().toString());
                editText=findViewById(R.id.mail_records_receiver_info_edittext2);
                m.setReceiver_tel(editText.getText().toString());
                editText=findViewById(R.id.mail_records_receiver_address_edittext1);
                m.setReceiving_province(editText.getText().toString());
                editText=findViewById(R.id.mail_records_receiver_address_edittext2);
                m.setReceiving_city(editText.getText().toString());
                editText=findViewById(R.id.mail_records_receiver_address_edittext3);
                m.setReceiving_county(editText.getText().toString());
                editText=findViewById(R.id.mail_records_receiver_address_edittext4);
                m.setReceiving_district_in_detail(editText.getText().toString());
                MaterialBetterSpinner spinner=(MaterialBetterSpinner)findViewById(R.id.mail_records_spinner);
                m.setPackage_class(spinner.getText().toString());
                editText=findViewById(R.id.mail_records_edittext4_2);
                String s=editText.getText().toString();
                if(s.length()>0){
                    m.setPackage_weight(Double.parseDouble(editText.getText().toString()));
                }
                else{
                    m.setPackage_weight(0.);
                }
                CheckBox checkBox1=(CheckBox)findViewById(R.id.checkBox5_1);
                CheckBox checkBox2=(CheckBox)findViewById(R.id.checkBox5_2);
                if(checkBox1.isChecked()&&checkBox2.isChecked()){
                    Toast toast1=Toast.makeText(MailRecords.this,"查验结论只能选中一项",Toast.LENGTH_SHORT    );
                    toast1.setGravity(Gravity.CENTER, 0, 0);
                    toast1.show();
                    return;
                }
                if(checkBox1.isChecked()){
                    m.setCheck_conclusion("合格");
                }
                if(checkBox2.isChecked()){
                    m.setCheck_conclusion("截留");
                }
                CheckBox checkBox;
                checkBox=findViewById(R.id.checkBox6_1);
                m.setIs_destroy(checkBox.isChecked());
                checkBox=findViewById(R.id.checkBox6_2);
                m.setIs_letgo(checkBox.isChecked());
                checkBox=findViewById(R.id.checkBox6_3);
                m.setIs_letcheck(checkBox.isChecked());
                checkBox=findViewById(R.id.checkBox6_4);
                m.setIs_letback(checkBox.isChecked());
                editText=findViewById(R.id.mail_records_edittext7_1);
                m.setIn_storage_time(editText.getText().toString());
                editText=findViewById(R.id.mail_records_edittext7_2);
                m.setIn_storage_site(editText.getText().toString());
                editText=findViewById(R.id.mail_records_edittext8_1);
                m.setOut_storage_time(editText.getText().toString());
                editText=findViewById(R.id.mail_records_edittext8_2);
                m.setOut_storage_site(editText.getText().toString());
                editText=findViewById(R.id.mail_records_edittext10);
                m.setOperator(editText.getText().toString());
                //获取当前时间
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss");// HH:mm:ss
                Date date = new Date(System.currentTimeMillis());
                m.setOperating_time(simpleDateFormat.format(date));
                if(picturePath!=null){
                    m.setPic_path(picturePath);
                    m.setType(picturePath.substring(picturePath.lastIndexOf((int)'.')));
                }

                if(dbserver.insertMailData(m)==1){
                    Toast toast1=Toast.makeText(MailRecords.this,"已保存",Toast.LENGTH_SHORT    );
                    toast1.setGravity(Gravity.CENTER, 0, 0);
                    toast1.show();
                }
                else{
                    Toast toast1=Toast.makeText(MailRecords.this,"请重试",Toast.LENGTH_SHORT    );
                    toast1.setGravity(Gravity.CENTER, 0, 0);
                    toast1.show();
                }
            }
        });
    }


    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private PrintJob print(String name, PrintDocumentAdapter adapter, PrintAttributes attrs) {
        startService(new Intent(this, PrintJobMonitorService.class));
        return(mgr.print(name, adapter, attrs));
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        /*结果回调*/
        if (requestCode == PictureSelector.SELECT_REQUEST_CODE) {
            if (data != null) {
                picturePath = data.getStringExtra(PictureSelector.PICTURE_PATH);
                Bitmap bitmap = BitmapFactory.decodeFile(picturePath);
                imageView.setImageBitmap(bitmap);

            }
        }
    }

}

